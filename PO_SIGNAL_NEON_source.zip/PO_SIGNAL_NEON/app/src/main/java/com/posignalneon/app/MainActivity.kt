package com.posignalneon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Bg = Color(0xFF080B10)
private val Panel = Color(0xFF121923)
private val Neon = Color(0xFF35F2A0)
private val Red = Color(0xFFFF5268)
private val Muted = Color(0xFF9AA8B8)

data class Signal(val pair: String, val direction: String, val confidence: Int, val expiry: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SignalApp() }
    }
}

@Composable
fun SignalApp() {
    val pairs = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "EUR/GBP", "EUR/JPY", "GBP/JPY", "OTC — DEMO")
    var selected by remember { mutableStateOf("EUR/USD") }
    var signals by remember { mutableStateOf(listOf<Signal>()) }
    var status by remember { mutableStateOf("Ожидание запуска анализа") }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Neon,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(18.dp)
        ) {
            Text("PO SIGNAL", color = Neon, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("N E O N   •   ANDROID SIGNAL TERMINAL", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("РЫНОЧНЫЙ СКАНЕР", color = Muted, fontSize = 11.sp)
                    Text("Автоанализ", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                }
                Surface(color = Color(0xFF123326), shape = RoundedCornerShape(50)) {
                    Text("● DEMO", color = Neon, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("ВЫБЕРИ АКТИВ", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(selected, color = Color.White)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            pairs.forEach { pair ->
                                DropdownMenuItem(text = { Text(pair) }, onClick = { selected = pair; expanded = false })
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("ТАЙМФРЕЙМ / ЭКСПИРАЦИЯ", color = Muted, fontSize = 11.sp)
                    Text("1 минута  •  демо-режим", color = Neon, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    val call = Random.nextBoolean()
                    signals = listOf(Signal(selected, if (call) "CALL" else "PUT", Random.nextInt(55, 86), "1 мин")) + signals
                    status = "Создан демонстрационный пример"
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neon),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("СГЕНЕРИРОВАТЬ ДЕМО-СИГНАЛ", color = Color(0xFF04120C), fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(10.dp))
            Text(status, color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(16.dp))
            Text("ПОСЛЕДНИЕ СИГНАЛЫ", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (signals.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Text("Пока нет сигналов. Нажми кнопку выше, чтобы проверить интерфейс.",
                        color = Muted, modifier = Modifier.padding(18.dp))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(signals) { signal ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(signal.pair, color = Color.White, fontWeight = FontWeight.Bold)
                                    Text("Экспирация: ${signal.expiry}", color = Muted, fontSize = 11.sp)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(signal.direction, color = if (signal.direction == "CALL") Neon else Red, fontWeight = FontWeight.Black)
                                    Text("${signal.confidence}%* ", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("* Случайные демонстрационные значения, не прогноз и не вероятность выигрыша. Реальные котировки и OTC пока не подключены.",
                color = Muted, fontSize = 10.sp)
        }
    }
}
